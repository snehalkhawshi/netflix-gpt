import { useEffect } from "react";
import { useDispatch , useSelector } from "react-redux";
import { addTrailerVideo } from "../utils/moviesSlice";
import { API_OPTIONS } from "../utils/constants";
const useMovietrailer = (movieId) => {

    console.log(movieId);
    const dispatch = useDispatch();

    const trailerVideo = useSelector((store) => store.movies.trailerVideo);
    // fetch trailor video
    const getMovieVideos = async () => {
        const data = await fetch("https://api.themoviedb.org/3/movie/" + movieId + "/videos" , API_OPTIONS);

        const json = await data.json();

        console.log(json,"ssssssssssssssssssssss")

        const filterData = json.results.filter((video)=>  video.type === "Trailer");

        const trailer = filterData.length ? filterData[0] : json.results[0];

        dispatch(addTrailerVideo(trailer));
    };

    useEffect(() => {
        !trailerVideo && getMovieVideos();
    },[]);
}

export default useMovietrailer;